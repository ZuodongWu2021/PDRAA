#pragma once

#define NUMBER_OF_LOGICAL_CORES      8
#define NUMBER_OF_PHYSICAL_CORES     8
#define IS_64BIT                     1
#define HAS_SSE2                     1

#define IS_LINUX                 1
/* #undef IS_MACOS */
/* #undef IS_WINDOWS */
